<?php
require_once "game/GameConst.php";

// ��Ϸ�浵����
class GameData
{
    public function __construct($data)
    {

    }

}
?>