<?php
require_once "game/GameConst.php";

// 语言
class Language
{
    const GameStart_Voice = "请问想玩什么游戏? 第一个为猜数字, 第二个是猜地理";
    const GameStart_Text = "请问想玩什么游戏? 第一个为猜数字, 第二个是猜地理";
    
    const GameExit_Voice = "再见少年，我已拉黑你了。";
    const GameExit_Text = "再见少年，什么人啊。";
    
    const GameUnknow_Voice = "对不起, 我不是很理解你说什么. ";
    const GameUnknow_Text = "对不起, 我不是很理解你说什么. ";
}
?>