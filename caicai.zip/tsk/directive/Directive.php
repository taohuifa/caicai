<?php
class Directive{
	public $type;
	public function __construct() {
        $this->type = NULL;
    }
}
?>