<?php
class OrderInfo{
	public $name;
	public $description;
	public $userId;
	public $items;
	public function __construct() {
    }
}
?>